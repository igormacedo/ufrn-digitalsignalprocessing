//see radix-4 example in Chapter 6

#include "dsk6713_aic23.h"                 //codec support
Uint32 fs=DSK6713_AIC23_FREQ_8KHZ;  			//set sampling rate
#define DSK6713_AIC23_INPUT_MIC 0x0015
#define DSK6713_AIC23_INPUT_LINE 0x0011
Uint16 inputsource=DSK6713_AIC23_INPUT_LINE; 	//select input

#include <math.h>
#define N 256                       //no of complex FFT points

unsigned short JIndex[4*N];         //index for digit reversal
unsigned short IIndex[4*N];         //index for digit reversal

typedef struct Complex_tag {float re,im;}Complex;
Complex W[3*N/2];                   //array for twiddle constants
Complex x[N];                       //N complex data values
double delta = 2*3.14159265359/N;

int count;
short input_buffer[N] = {0};  //to store input samples...same as x
float output_buffer[7] = {0}; //to store magnitude of FFT
short buffer_count, i, j;
short nFlag;                  //indicator to begin FFT
short nRow, nColumn;
//double delta;
float tempvalue;

#pragma DATA_ALIGN(x,sizeof(Complex)); //align x on boundary
#pragma DATA_ALIGN(W,sizeof(Complex)); //align W on boundary

interrupt void c_int11()
{
	input_buffer[buffer_count] = input_sample();
	output_sample((short)input_buffer[buffer_count++]);
	
	if(buffer_count >= N)        //if accum more than N points->begin FFT
  	{
	   buffer_count = 0;          //reset buffer_count
	   nFlag = 0;                 //flag to signal completion
	   for(i = 0; i < N; i++)
       {
	   		x[i].re = (float)input_buffer[i];  //real part of input
			x[i].im = 0.0;                     //imaginary part of input
 		}
  	}
}

void main(void)
{
	nFlag = 1;
	buffer_count = 0;
	
	R4DigitRevIndexTableGen(N,&count,IIndex,JIndex); //for digit rev
	for(i = 0; i < 3*N/4; i++)
  	{
   		W[i].re = cos(delta*i);          //real component of W
  		W[i].im = sin(delta*i);          //Im component of W
  	}

	DSK6713_LED_init();			      //init LED from BSL
	
    //generate twiddle constants, then index for digit reversal
 	comm_intr();
	
	while(1)                           //infinite loop
	{
		while(nFlag);   //wait for ISR to finish buffer accum samples
		nFlag = 1;

		cfftr4_dif(x, W, N);              //radix-4 FFT function
		digit_reverse((double *)x,IIndex,JIndex,count); //unscramble

		//call radix-4 FFT, then digit reverse function
		
		output_buffer[0]=(float) sqrt(x[22].re*x[22].re + x[22].im*x[22].im);  // 697Hz
		output_buffer[1]=(float) sqrt(x[25].re*x[25].re + x[25].im*x[25].im);  // 770Hz
		output_buffer[2]=(float) sqrt(x[28].re*x[28].re + x[28].im*x[28].im);  //852Hz
		output_buffer[3]=(float) sqrt(x[31].re*x[31].re + x[31].im*x[31].im);  // 941Hz
		output_buffer[4]=(float) sqrt(x[39].re*x[39].re + x[39].im*x[39].im);  // 1209Hz
		output_buffer[5]=(float) sqrt(x[43].re*x[43].re + x[43].im*x[43].im);  // 1336Hz
		output_buffer[6]=(float) sqrt(x[47].re*x[47].re + x[47].im*x[47].im);  // 1477Hz
		
		tempvalue = 0;                    //choose largest row frequency
		nRow = 0;		
		for(j = 0; j < 4; j++)
		{
			if(tempvalue < output_buffer[j])
		 	{
		  		if(output_buffer[j] > 0.5e4)
				{
			        nRow = j + 1;
			        tempvalue = output_buffer[j];
				}
	 		}
	    }      //end of for loop  
	        
			
	  	tempvalue = 0;                    //choose largest column frequency
	  	nColumn = 0;
	  	for(j = 4; j < 7; j++)
	  	{
			if(tempvalue < output_buffer[j])
		 	{
				if(output_buffer[j] > 0.5e4)
				{
					nColumn = j - 3;
					tempvalue = output_buffer[j];
                }
			}
	  	} //end of for loop


		if((nRow==1)&&(nColumn==1))      //for button 0001 ("1")
		{DSK6713_LED_on(0);DSK6713_LED_off(1);DSK6713_LED_off(2);DSK6713_LED_off(3);}
	
		if((nRow==1)&&(nColumn==2))      //for button 0010 ("2")
		{DSK6713_LED_off(0);DSK6713_LED_on(1);DSK6713_LED_off(2);DSK6713_LED_off(3);}
	
		if((nRow==1)&&(nColumn==3))      //for button 0010 ("3")
		{DSK6713_LED_on(0);DSK6713_LED_on(1);DSK6713_LED_off(2);DSK6713_LED_off(3);}
	
		if((nRow==2)&&(nColumn==1))      //for button 0010 ("4")
		{DSK6713_LED_off(0);DSK6713_LED_off(1);DSK6713_LED_on(2);DSK6713_LED_off(3);}
	
		if((nRow==2)&&(nColumn==2))      //for button 0010 ("5")
		{DSK6713_LED_on(0);DSK6713_LED_off(1);DSK6713_LED_on(2);DSK6713_LED_off(3);}
	
		if((nRow==2)&&(nColumn==3))      //for button 0010 ("6")
		{DSK6713_LED_off(0);DSK6713_LED_on(1);DSK6713_LED_on(2);DSK6713_LED_off(3);}
	
		if((nRow==3)&&(nColumn==1))      //for button 0010 ("7")
		{DSK6713_LED_on(0);DSK6713_LED_on(1);DSK6713_LED_on(2);DSK6713_LED_off(3);}
	
		if((nRow==3)&&(nColumn==2))      //for button 0010 ("8")
		{DSK6713_LED_off(0);DSK6713_LED_off(1);DSK6713_LED_off(2);DSK6713_LED_on(3);}
	
		if((nRow==3)&&(nColumn==3))      //for button 0010 ("9")
		{DSK6713_LED_on(0);DSK6713_LED_off(1);DSK6713_LED_off(2);DSK6713_LED_on(3);}
	
		if((nRow==4)&&(nColumn==1))      //for button 0010 ("*")
		{DSK6713_LED_off(0);DSK6713_LED_on(1);DSK6713_LED_off(2);DSK6713_LED_on(3);}
	
		if((nRow==4)&&(nColumn==2))      //for button 0010 ("0")
		{DSK6713_LED_on(0);DSK6713_LED_on(1);DSK6713_LED_off(2);DSK6713_LED_on(3);}
	
		if((nRow==4)&&(nColumn==3))      //for button 0010 ("0")
		{DSK6713_LED_off(0);DSK6713_LED_off(1);DSK6713_LED_on(2);DSK6713_LED_on(3);}
	
		if((nRow==0)&&(nColumn==0))  
		{DSK6713_LED_off(0);DSK6713_LED_off(1);DSK6713_LED_off(2);DSK6713_LED_off(3);}

	}  //end of while (1) infinite loop
}  //end of main 
